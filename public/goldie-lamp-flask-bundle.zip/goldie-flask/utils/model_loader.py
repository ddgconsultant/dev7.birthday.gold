from llama_cpp import Llama

MODEL_DIR = "/var/www/BIRTHDAY_SERVER/goldie-web/models"

def load_llm(model_name):
    return Llama(model_path=f"{MODEL_DIR}/{model_name}", n_ctx=2048)
