from flask import Flask
from routes.chat import chat_bp
from routes.webhook_streamer import webhook_bp

app = Flask(__name__)
app.register_blueprint(chat_bp, url_prefix="/chat")
app.register_blueprint(webhook_bp, url_prefix="/webhook-streamer")

@app.route("/health")
def health():
    return {"status": "running"}

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000)
