from flask import Blueprint, request, jsonify
from utils.model_loader import load_llm
import requests

webhook_bp = Blueprint('webhook', __name__)

@webhook_bp.route("", methods=["POST"])
def webhook_streamer():
    data = request.get_json()
    prompt = data.get("message", "Hello")
    webhook_url = data.get("webhook")
    model_name = data.get("model", "deepseek-chat-1.3b-Q4_K.gguf")
    if not webhook_url:
        return jsonify({"error": "Missing webhook URL"}), 400
    llm = load_llm(model_name)
    for chunk in llm.create_completion(prompt, stream=True, max_tokens=300):
        token = chunk['choices'][0]['text']
        requests.post(webhook_url, json={"token": token})
    return jsonify({"status": "streamed"})
