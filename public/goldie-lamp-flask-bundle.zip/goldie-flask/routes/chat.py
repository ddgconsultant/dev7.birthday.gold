from flask import Blueprint, request, Response
from utils.model_loader import load_llm

chat_bp = Blueprint('chat', __name__)

@chat_bp.route("", methods=["POST"])
def chat():
    data = request.get_json()
    prompt = data.get("message", "Hello")
    model_name = data.get("model", "deepseek-chat-1.3b-Q4_K.gguf")
    llm = load_llm(model_name)
    def stream_response():
        for chunk in llm.create_completion(prompt, stream=True, max_tokens=300):
            yield chunk['choices'][0]['text']
    return Response(stream_response(), mimetype="text/plain")
