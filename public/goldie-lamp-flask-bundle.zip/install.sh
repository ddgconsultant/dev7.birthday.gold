#!/bin/bash
set -e

echo "🔧 Installing Apache, PHP, and required modules..."
apt update
apt install -y apache2 php libapache2-mod-php python3 python3-venv python3-pip

echo "📁 Setting up directories..."
mkdir -p /var/www/BIRTHDAY_SERVER
cp -r goldie-web /var/www/BIRTHDAY_SERVER/
cp -r goldie-flask /var/www/BIRTHDAY_SERVER/

echo "🧠 Creating Flask virtual environment..."
cd /var/www/BIRTHDAY_SERVER/goldie-flask
python3 -m venv venv
source venv/bin/activate
pip install flask llama-cpp-python requests

echo "⚙️ Creating systemd service for goldie-chat..."
cat <<EOF > /etc/systemd/system/goldie-chat.service
[Unit]
Description=Goldie Flask Chat API
After=network.target

[Service]
User=www-data
Group=www-data
WorkingDirectory=/var/www/BIRTHDAY_SERVER/goldie-flask
ExecStart=/var/www/BIRTHDAY_SERVER/goldie-flask/venv/bin/python3 /var/www/BIRTHDAY_SERVER/goldie-flask/app.py
Restart=always

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable goldie-chat
systemctl start goldie-chat

echo "🌐 Configuring Apache vhost..."
cat <<EOF > /etc/apache2/sites-available/goldie.conf
<VirtualHost *:80>
    ServerName goldie-ca00
    DocumentRoot /var/www/BIRTHDAY_SERVER/goldie-web

    <Directory "/var/www/BIRTHDAY_SERVER/goldie-web">
        AllowOverride All
        Require all granted
    </Directory>

    <FilesMatch \.php$>
        SetHandler application/x-httpd-php
    </FilesMatch>

    ProxyPass "/chat" "http://127.0.0.1:5000/chat"
    ProxyPassReverse "/chat" "http://127.0.0.1:5000/chat"

    ProxyPass "/webhook-streamer" "http://127.0.0.1:5000/webhook-streamer"
    ProxyPassReverse "/webhook-streamer" "http://127.0.0.1:5000/webhook-streamer"
</VirtualHost>
EOF

a2enmod proxy proxy_http
a2ensite goldie
systemctl reload apache2

echo "✅ Installation complete!"
