<?php
header('Content-Type: application/json');
// Future security logic here
?>